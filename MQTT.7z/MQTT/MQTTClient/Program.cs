﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MQTTnet;
using MQTTnet.Client;
using MQTTnet.Server;

namespace MQTTClient
{
    class Program
    {
        static void Main(string[] args)
        {
            var client = new Client();

            Console.WriteLine("connecting");
            while (!client.IsConnected) {
                Console.Write(".");
                System.Threading.Thread.Sleep(1000);
            }

            client.SubscribeAsync();
            Console.WriteLine("");
            Console.WriteLine("Connected");
            while (true) {
                var line = Console.ReadLine();
                client.publish(line);
            }
        }


        class Client {
            IMqttClient mqttClient;
            public Client() {
                Start();
            }

            async void Start() {

                mqttClient = new MqttFactory().CreateMqttClient();
                var clientId = "Client1" + new Random().Next(9999);
                var options = new MqttClientOptionsBuilder()
                    .WithClientId(clientId)
                    .WithTcpServer("172.22.204.170", 1884)
                    .WithWillMessage(new MqttApplicationMessageBuilder().WithTopic("test").WithPayload($"{clientId} ist Tot!! :(").Build())
                    .WithCleanSession()
                    .Build();
                await mqttClient.ConnectAsync(options);

                mqttClient.ApplicationMessageReceived += (s, e) =>
                {
                    Console.WriteLine("### RECEIVED APPLICATION MESSAGE ###");
                    Console.WriteLine($"+ Topic = {e.ApplicationMessage.Topic}");
                    Console.WriteLine($"+ Payload = {Encoding.UTF8.GetString(e.ApplicationMessage.Payload)}");
                    Console.WriteLine($"+ QoS = {e.ApplicationMessage.QualityOfServiceLevel}");
                    Console.WriteLine($"+ Retain = {e.ApplicationMessage.Retain}");
                    Console.WriteLine();
                };



            }

            public void publish(String message) {
                mqttClient.PublishAsync(new MqttApplicationMessageBuilder().WithPayload(message).WithTopic("test").Build());
            }
            

            public bool IsConnected => mqttClient.IsConnected;

            public async void SubscribeAsync() {
                Console.WriteLine("### CONNECTED WITH SERVER ###");

                // Subscribe to a topic
                await mqttClient.SubscribeAsync(new TopicFilterBuilder().WithTopic("test").Build());

                Console.WriteLine("### SUBSCRIBED ###");
            }

           
    }
    }
}
