﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MQTT;
using MQTTnet;
using MQTTnet.Server;
using System.Net;

namespace MQTT
{
    class Program
    {
        static void Main(string[] args)
        {

            Server server = new Server();

            Console.ReadKey();
             
            while (true)
            {
                Console.ReadKey();
            }
        }


        class Server {

            IMqttServer mqttServer;
             public Server() {
                startServer();
             }

            async void startServer()
            {
                var optionsBuilder = new MqttServerOptionsBuilder()
                    .WithConnectionBacklog(100)
                    .WithDefaultEndpointPort(1884)
                    .WithDefaultEndpointBoundIPAddress(IPAddress.Parse("172.22.204.12"))
                    ;
                mqttServer = new MqttFactory().CreateMqttServer();
                await mqttServer.StartAsync(optionsBuilder.Build());

                mqttServer.ClientConnected += MqttServer_ClientConnected;
            }

            private void MqttServer_ClientConnected(object sender, MqttClientConnectedEventArgs e)
            {
                Console.WriteLine(e);
            }
        }
    }
}

